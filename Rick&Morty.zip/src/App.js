import logo from './logo.svg';
import './App.css';
import Webpages from './webpages';
function App() {
  return (
    <div>
      <Webpages />
    </div>
  );
}
export default App;
