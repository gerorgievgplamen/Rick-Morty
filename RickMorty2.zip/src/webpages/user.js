import React from 'react';
const User = () => {
return(
        <div>
            <h1>User Details</h1>
        </div>
    );
}
export default User;